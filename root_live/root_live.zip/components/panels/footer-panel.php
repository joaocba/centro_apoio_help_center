<!-- FOOTER PANEL -->
<footer id="footer-panel" class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex justify-content-center small">
            <div class="text-muted">&copy; Copyright 2022-<script>document.write(new Date().getFullYear())</script>, Centro de Apoio</div>
        </div>
    </div>
</footer>