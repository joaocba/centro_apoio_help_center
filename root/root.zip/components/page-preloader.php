<script>
    $(window).on('load', function() {
        //$('#loading').hide();
        $('#loading').fadeOut();
    })
</script>